# iOS-RatingBar swift版的评分控件
### 描述
跟Android的RatingBar一样有两种模式，评分模式和只读模式<br />
支持视图编辑，自定义星星数量，评分等级<br />
另外还能支持非整数星，0.5颗星，0.1颗星<br />
可以开启动画效果
### Demo

![](https://github.com/saiwu-bigkoo/iOS-RatingBar/blob/master/preview/ratingbardemo.gif)
